#Program to find: MaxMin Value
# USN: 1RUA25BCA0032 Name: Gayathri V Shenoy


a=int(input("Enter A"))
b=int(input("Enter B"))
c=int(input("Enter C"))

if(a>b and a>c):
    print("A is maximum")
elif (b>a and b>c):
    print("B is maximum")
else:
    print("C is maximum")

if(a<b and a<c):
    print("A is minimum")
elif (b<c and b<a):
    print("B is minimum")
else:
    print("C is minimum")
