#Program to find: Temperature conversion
# USN: 1RUA25BCA0032 Name: Gayathri V Shenoy


temp= float(input("Enter temperature"))
value= int(input("Enter 1 if you want to convert from Celsius to Farenheit, Enter 2 if you want to convert from Farenheit to Celcius"))

match value:
    case 1:
        print((temp*9/5)+32)
    case 2:
        print((temp-32)*5/9)
    case _:
        print("Invalid")
        
