#Program to find: Simple_Calculator
#USN: 1RUA25BCA0032 Name: Gayathri V Shenoy


a= float(input("Enter first number: "))
b=float(input("Enter second number: "))

op=int(input("put 1 for addition, 2 for subtraction, 3 for multiplication, and 4 for division"))

match op:
    case 1:
        print(a+b)
    case 2:
        print(a-b)
    case 3:
        print(a*b)
    case 4:
        print(a/b)
    case _:
        print("Invalid number")
